// Global using directives

global using Microsoft.Extensions.Configuration;